from flask import Flask, jsonify
import sqlite3 as sql

app = Flask(__name__)
@app.route("/api/v1/percorsi")
def percorsi():
    connection = sql.connect("./percorsi.db")
    cursor = connection.cursor()
    cursor.execute('''SELECT * FROM Percorso''')
    percorsi = cursor.fetchall()
    temp = jsonify(percorsi)
    print(temp)
    connection.commit()
    connection.close()
    return temp

#passo come parametro della funzione
@app.route("/api/v1/percorsi/<id>")
def percorso(id):
    connection = sql.connect("./percorsi.db")
    cursor = connection.cursor()
    cursor.execute('''SELECT * FROM Percorso, Movimento, Mossa WHERE Percorso.id = ? AND Mossa.codPercorso = Percorso.id AND Movimento.id = Mossa.codMovimento''', (id,))  #qua ci sarà una query al db
    percorso = cursor.fetchall()
    temp = jsonify(percorso)
    print(temp)
    connection.commit()
    connection.close()
    return temp    #imposta anche il content-type

def main():   
    app.run()
   


# http://127.0.0.1:5000/api/v1/percorsi/0
if __name__ == "__main__":
    main()